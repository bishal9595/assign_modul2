import { Component } from "@angular/core";

@Component({
    selector:'add-p',
    templateUrl:'addproduct.html'
})
export class AddProductComponent{
    pId:number;
    pName:string;
    pCost:number;
    pSel:string;
    on:any;
    off:any;
    value:string;
    opt:any;
    option:string=" ";
    prodAll:any[]=[];

addData(){
    this.on=document.getElementById('yes') as HTMLInputElement
    if(this.on.checked==true)
    {
        this.value="Yes";
    }
    this.off=document.getElementById('no') as HTMLInputElement
    if(this.off.checked==true)
    {
        this.value="No";
    }
    this.opt=document.getElementById('prod1') as HTMLInputElement
    if(this.opt.checked==true)
    {
        this.option=this.option+" "+this.opt.value
    }
    this.opt=document.getElementById('prod2') as HTMLInputElement
    if(this.opt.checked==true)
    {
        this.option=this.option+" "+this.opt.value
    }
    this.opt=document.getElementById('prod3') as HTMLInputElement
    if(this.opt.checked==true)
    {
        this.option=this.option+" "+this.opt.value
    }
    this.opt=document.getElementById('prod4') as HTMLInputElement
    if(this.opt.checked==true)
    {
        this.option=this.option+" "+this.opt.value
    }
    this.prodAll.push({pId:this.pId,pName:this.pName,pCost:this.pCost,pSel:this.pSel,value:this.value,option:this.option});
  
}}
