import { Component, OnInit, Input } from "@angular/core";
import { EmployeeService } from './app.employeeService';

@Component({
    selector:'show-comp',
    templateUrl:'app.showEmployee.html'
})
export class ShowEmployeeComponent implements OnInit{
    
    empAll:any[];
    constructor(private service:EmployeeService){}
   
    ngOnInit(){
        this.service.getAllEmployee().subscribe((data:any)=>this.empAll=data);
    }
    delete(n:number){
        this.empAll.splice(n,1);
    }

  
   
}