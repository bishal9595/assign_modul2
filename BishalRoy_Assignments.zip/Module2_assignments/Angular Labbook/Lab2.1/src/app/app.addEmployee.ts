import { Component } from "@angular/core";

@Component({
    selector:'add-emp',
    templateUrl:'app.add.html'
})  
export class AddEmployeeComponent{
    empId:number;
    empName:string;
    empSalary:number;
    empDepartment:string;
    empId2:number;
    empName2:string;
    empSalary2:number;
    empDepartment2:string;
    empId3:number;
    empAll:any[]=[
        {empId:1001,empName:"ABCD",empSalary:333.33,empDepartment:"Java"},
        {empId:1002,empName:"abcd",empSalary:666.33,empDepartment:"Oracle"},
        {empId:1005,empName:"Ariz",empSalary:999.33,empDepartment:"DotNet"},

    ];
    addEmployee():any{
        this.empAll.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment})
        console.log("Employee Added......"+this.empAll);
        this.empId=null;
        this.empName=null;
        this.empSalary=null;
        this.empDepartment=null;
    }
    deleteEmployee(data:number):any{
        this.empAll.splice(data,1);
        alert("Data "+(data+1)+" deleted");
    }
    updateEmployee():any{
          

        for(let data of this.empAll){
            if(data.empId==this.empId3){ 
                data.empId=this.empId2;
                data.empName=this.empName2;
                data.empSalary=this.empSalary2;
                data.empDepartment=this.empDepartment2
                
    }
}
this.empId2=null;
this.empName2=null;
this.empSalary2=null;
this.empDepartment2=null;
alert("Row  Updated");
        
    }
    updateEmployee2(data:number):any{
        this.empId2=this.empAll[data].empId;
        this.empId3=this.empAll[data].empId;
        this.empName2=this.empAll[data].empName;
        this.empSalary2=this.empAll[data].empSalary;
        this.empDepartment2=this.empAll[data].empDepartment;

    }
}
