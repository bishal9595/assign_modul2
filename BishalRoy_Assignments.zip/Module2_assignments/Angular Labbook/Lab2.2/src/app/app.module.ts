import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { AddEmployeeComponent } from './app.addEmployee';
import { MatSortModule } from '@angular/material';
@NgModule({
    imports: [
        BrowserModule,
        MatSortModule
    ],
    declarations: [
        AppComponent,
        AddEmployeeComponent
        ],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }